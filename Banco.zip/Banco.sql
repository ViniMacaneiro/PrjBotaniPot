-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           10.4.27-MariaDB - mariadb.org binary distribution
-- OS do Servidor:               Win64
-- HeidiSQL Versão:              12.5.0.6677
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Copiando estrutura do banco de dados para hortaprototipo
DROP DATABASE IF EXISTS `hortaprototipo`;
CREATE DATABASE IF NOT EXISTS `hortaprototipo` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `hortaprototipo`;

-- Copiando estrutura para tabela hortaprototipo.cliente
DROP TABLE IF EXISTS `cliente`;
CREATE TABLE IF NOT EXISTS `cliente` (
  `idCliente` int(11) NOT NULL AUTO_INCREMENT,
  `Nome` varchar(45) NOT NULL,
  `Senha` varchar(45) NOT NULL,
  `Email` varchar(45) NOT NULL,
  PRIMARY KEY (`idCliente`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Copiando dados para a tabela hortaprototipo.cliente: ~1 rows (aproximadamente)
DELETE FROM `cliente`;
INSERT INTO `cliente` (`idCliente`, `Nome`, `Senha`, `Email`) VALUES
	(1, 'Winicius', '12345678', 'Vinicius.Macaneiro');

-- Copiando estrutura para tabela hortaprototipo.coleta
DROP TABLE IF EXISTS `coleta`;
CREATE TABLE IF NOT EXISTS `coleta` (
  `Horta_idHorta` int(11) NOT NULL,
  `Cliente_idCliente` int(11) NOT NULL,
  `Umidade` int(11) NOT NULL,
  `Solar` int(11) NOT NULL,
  `DATACOLETA` datetime NOT NULL,
  PRIMARY KEY (`Horta_idHorta`,`Cliente_idCliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Copiando dados para a tabela hortaprototipo.coleta: ~0 rows (aproximadamente)
DELETE FROM `coleta`;

-- Copiando estrutura para tabela hortaprototipo.componentes
DROP TABLE IF EXISTS `componentes`;
CREATE TABLE IF NOT EXISTS `componentes` (
  `idComponentes` int(11) NOT NULL AUTO_INCREMENT,
  `Modelo` varchar(45) NOT NULL,
  `Marca` varchar(45) NOT NULL,
  PRIMARY KEY (`idComponentes`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Copiando dados para a tabela hortaprototipo.componentes: ~1 rows (aproximadamente)
DELETE FROM `componentes`;
INSERT INTO `componentes` (`idComponentes`, `Modelo`, `Marca`) VALUES
	(1, '0320329', 'Leonardo');

-- Copiando estrutura para tabela hortaprototipo.horta
DROP TABLE IF EXISTS `horta`;
CREATE TABLE IF NOT EXISTS `horta` (
  `idHorta` int(11) NOT NULL AUTO_INCREMENT,
  `Nome` varchar(45) NOT NULL,
  `Umidade_Percentual` int(11) NOT NULL,
  `Solar_Percentual` int(11) NOT NULL,
  `Agua_recomendada` double NOT NULL,
  `idCliente` int(11) NOT NULL,
  PRIMARY KEY (`idHorta`),
  KEY `idCLiente` (`idCliente`),
  CONSTRAINT `idCLiente` FOREIGN KEY (`idCliente`) REFERENCES `cliente` (`idCliente`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Copiando dados para a tabela hortaprototipo.horta: ~0 rows (aproximadamente)
DELETE FROM `horta`;

-- Copiando estrutura para tabela hortaprototipo.horta_componentes
DROP TABLE IF EXISTS `horta_componentes`;
CREATE TABLE IF NOT EXISTS `horta_componentes` (
  `Horta_idHorta` int(11) NOT NULL,
  `Horta_Cliente_idCliente` int(11) NOT NULL,
  `Componentes_idComponentes` int(11) NOT NULL,
  PRIMARY KEY (`Horta_idHorta`,`Horta_Cliente_idCliente`,`Componentes_idComponentes`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Copiando dados para a tabela hortaprototipo.horta_componentes: ~0 rows (aproximadamente)
DELETE FROM `horta_componentes`;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
